const express = require('express');
const path = require('path');
const app = express();

app.get('/fone-de-ouvido', function(req, res) {
    res.sendFile(path.join(__dirname + '/fone-de-ouvido.html'));
});

app.get('/carregador-iphone', function(req, res) {
    res.sendFile(path.join(__dirname + '/carregador-iphone.html'));
});

app.get('/carregador-universal', function(req, res) {
    res.sendFile(path.join(__dirname + '/carregador-universal.html'));
});

app.get('/suporte', function(req, res) {
    res.sendFile(path.join(__dirname + '/suporte.html'));
});

app.listen(3000, function () {
  console.log('App is listening on port 3000!');
});